from django.apps import AppConfig


class CheckoutpgclientConfig(AppConfig):
    name = 'checkoutpgclient'
